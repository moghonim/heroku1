# Lama Marketplace

```
- For MySQL
```

spring.datasource.url= jdbc:mysql://localhost:3306/stack_deans?useSSL=false
spring.datasource.username= root
spring.datasource.password= 1234

spring.jpa.properties.hibernate.dialect= org.hibernate.dialect.MySQL5InnoDBDialect
spring.jpa.hibernate.ddl-auto= update

```
## Run Spring Boot application
```

mvn spring-boot:run

```

