package com.stackdeans.loginregister.models;

public enum EPermission {
    all,
    no,
    write,
    read
}
