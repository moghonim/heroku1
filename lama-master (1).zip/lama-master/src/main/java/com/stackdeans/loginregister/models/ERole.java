package com.stackdeans.loginregister.models;

/**
 * @author Ghonim
 */
public enum ERole {
    ROLE_USER,
    ROLE_VENDOR,
    ROLE_MODERATOR,
    ROLE_ADMIN
}
