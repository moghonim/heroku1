INSERT INTO roles(name) VALUES('ROLE_USER');
INSERT INTO roles(name) VALUES('ROLE_MODERATOR');
INSERT INTO roles(name) VALUES('ROLE_ADMIN');
INSERT INTO roles(name) VALUES('ROLE_VENDOR');

--INSERT INTO `stack_deans`.`permission`
--(`permission_type`)
--VALUES
--("all");
--INSERT INTO `stack_deans`.`permission`
--(`permission_type`)
--VALUES
--("null");



